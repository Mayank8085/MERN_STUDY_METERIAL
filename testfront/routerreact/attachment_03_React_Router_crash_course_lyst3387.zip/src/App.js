import React from "react";

export default function App() {
  return (
    <div>
      <h1>App component</h1>
    </div>
  );
}
